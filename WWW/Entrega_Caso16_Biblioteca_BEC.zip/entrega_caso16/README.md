# Caso 16 · Biblioteca Municipal BEC

**Entrega académica funcional: backend Java 21, frontend responsive, API Gateway HTTPS y microservicios privados.**

## Leer primero

- **Informe de los diez módulos:** [`docs/informe.pdf`](docs/informe.pdf), [Word editable](docs/informe.docx) y [Markdown](docs/informe.md).
- **Contratos de las 35 operaciones:** [`docs/contratos.pdf`](docs/contratos.pdf), [Markdown](docs/contratos.md) y [OpenAPI](docs/openapi.json).
- **Diagramas:** [PDF A3](docs/diagramas.pdf) y [fuentes PlantUML, SVG y PNG](docs/diagramas/).
- **Trazabilidad:** [`docs/trazabilidad.csv`](docs/trazabilidad.csv). Resultados reales en [`evidencias/`](evidencias/).
- **Manual de usuario:** [`docs/manual_usuario.pdf`](docs/manual_usuario.pdf) o `https://localhost:8443/help.html` al iniciar.

**Límite importante:** las pruebas entregadas usan **H2 persistente en archivo**. El despliegue Oracle, su TCPS y sus procedimientos están preparados, pero **no ejecutados**: Docker no está disponible en el entorno WSL utilizado. Véase [validación Oracle](docs/validacion_oracle.md). Correo, huella y antirrobo usan adaptadores **de prueba**, no Internet ni dispositivos físicos. No se cobran multas: las sanciones son de tiempo.

No se recibió un frontend anterior; esta interfaz constituye la línea base nueva. Los nombres de integrantes y datos de portada deben completarse en el informe; no se inventaron.

## 1. Requisitos

Linux/WSL con **JDK 21** (incluye `keytool`), Maven **3.9.x**, Python **3.10+**, OpenSSL **3.x**, acceso a Maven Central para compilar y los puertos locales 8443, 9100–9108 libres. Docker Engine y Compose v2 son necesarios **solo** para contenedores/Oracle. Para laboratorio, reservar aproximadamente 3 GB de RAM; Oracle agrega al menos 3 GB.

Versiones de bibliotecas fijadas en `pom.xml` y `scripts/requirements*.txt`. No se necesitan Node, npm ni servicios de nube.

## 2. Inicio local reproducible — H2 explícito

Desde la raíz del proyecto, con `java`, `keytool`, `mvn`, `python3` y `openssl` en `PATH`:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r scripts/requirements.txt
mvn -B -ntp package
python3 scripts/setup.py --profile h2 --runtime .runtime
python3 scripts/run.py start
python3 scripts/seed.py --titles 100
```

El compilado `target/bec.jar` también está incluido. Para usarlo sin recompilar, omitir `mvn`, pero **no** la generación del runtime.

Abrir **https://localhost:8443**. Instalar como confiable la CA local **solo en un perfil de navegador de laboratorio**: `.runtime/setup/ca.crt`. No usar esa CA en producción. Las credenciales aleatorias se consultan **localmente** en `.runtime/demo-credentials.json`; nunca se incluyen en el ZIP, los informes ni los logs. `seed.py` activa dos lectores ficticios mediante la API del proveedor de correo de prueba.

Los diez procesos son independientes. Solo el gateway debe usarse desde el navegador. En ejecución local los puertos internos escuchan exclusivamente en `127.0.0.1`; un usuario del mismo host puede intentar conectarse, pero sin identidad técnica obtiene 403. El aislamiento de red de contenedores es una configuración adicional, aún pendiente de ejecutar aquí.

```bash
python3 scripts/run.py status
curl --cacert .runtime/setup/ca.crt https://localhost:8443/api/health
curl --cacert .runtime/setup/ca.crt 'https://localhost:8443/api/catalog?size=10&q=historia'
python3 scripts/run.py stop
```

`stop` conserva datos y claves. `setup.py` **se niega a sobrescribir** un runtime existente. Para un laboratorio nuevo, elegir otro directorio y puertos; no borrar datos de una instalación utilizada. No ejecutar los perfiles local y Docker sobre los mismos archivos H2.

## 3. Pruebas

```bash
mvn -B -ntp test
```

23 pruebas JUnit: 18 de integración/seguridad/negocio/fallas y cinco unitarias. Se generan certificados y siete BD H2 en archivo dentro de un runtime temporal exclusivo. Las pruebas HTTP/TLS arrancan diez listeners en una JVM de pruebas; el arranque anterior y las mediciones usan diez JVM independientes. El reloj simulado y los jobs manuales existen solo en las pruebas, no como endpoints de la aplicación.

Con el laboratorio iniciado y sembrado:

```bash
pip install -r scripts/requirements-docs.txt
python3 -m playwright install chromium
python3 scripts/browser_test.py
python3 scripts/load.py --seconds 10 --concurrency 1 8 16
python3 scripts/evidence.py
python3 scripts/test_tools.py
python3 scripts/contracts.py
python3 scripts/build_docs.py
python3 scripts/verify_delivery.py
```

El E2E crea un título y dos ejemplares ficticios por ejecución; la carga registra el tamaño efectivo del catálogo. No ejecutar estos generadores contra datos reales. Playwright ignora únicamente la CA local del navegador; los clientes API y Java verifican el certificado.

## 4. Contenedores y Oracle

```bash
python3 scripts/deploy.py init --profile h2
python3 scripts/deploy.py config --profile h2
python3 scripts/deploy.py up --profile h2
python3 scripts/deploy.py ps --profile h2
python3 scripts/deploy.py down --profile h2
```

Oracle utiliza un **runtime distinto**:

```bash
python3 scripts/deploy.py init --profile oracle
python3 scripts/deploy.py up --profile oracle
```

No dar por aprobado Oracle al arrancar el contenedor. Completar el [protocolo de aceptación](docs/validacion_oracle.md): compilación PL/SQL, conexión TCPS validada, permisos, persistencia, jobs y flujos reales. `down` no elimina volúmenes. La imagen Oracle usa una etiqueta de versión y debe fijarse por digest tras validarla.

`--no-lab` en `setup.py` oculta la bandeja de prueba, **no** instala un proveedor de correo real. El proyecto no está declarado listo para producción.

## 5. Estructura y operación

| Ruta | Contenido |
|---|---|
| `src/main/java/cl/bec/` | Transporte seguro, gateway, servicios, dominio, repositorio y adaptadores |
| `src/main/resources/schema.graphqls` | Esquema real del BFF privado |
| `src/test/java/cl/bec/` | Pruebas automáticas |
| `web/` | Interfaz y ayuda, sin credenciales ni dependencias CDN |
| `db/oracle/` | Migración V001 y procedimientos V002 |
| `compose*.yaml`, `deploy/` | Despliegue por proceso/contenedor y TCPS Oracle |
| `scripts/` | Setup, arranque, seed, carga, E2E, contratos, evidencias y documentación |
| `docs/`, `evidencias/` | Informe, anexos, decisiones, capturas y resultados verificables |
| `.runtime/` | **Privado; generado, no distribuido**: BD, claves, certificados, credenciales y logs |

Respaldo, revocación, rotación offline, clasificación y límites: [`docs/seguridad_operacion.md`](docs/seguridad_operacion.md). Logs estructurados contienen servicio, verbo, estado, duración y correlación, no cuerpos ni contraseñas. `/health` indica vida del proceso, no disponibilidad de todas las dependencias.

El ZIP se genera con `python3 scripts/package.py`. Incluye fuentes, documentos, evidencia y JAR; excluye runtimes, claves privadas, certificados locales, BD y logs privados.
